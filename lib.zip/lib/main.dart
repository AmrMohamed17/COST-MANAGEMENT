import 'package:flutter/material.dart';
import 'models/client.dart';
import 'models/invoice.dart';
import 'models/payment.dart';
import 'models/receipt.dart';
import 'models/report.dart';
import 'services/payment_system_manager.dart';
import 'utils/enums.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Payment System Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      home: const PaymentDemoPage(),
    );
  }
}

class PaymentDemoPage extends StatefulWidget {
  const PaymentDemoPage({super.key});

  @override
  State<PaymentDemoPage> createState() => _PaymentDemoPageState();
}

class _PaymentDemoPageState extends State<PaymentDemoPage> {
  final PaymentSystemManager manager = PaymentSystemManager();
  String _logOutput = "";
  Invoice? _selectedInvoice;
  Client? _selectedClient;
  Payment? _lastPayment;
  Receipt? _lastReceipt;
  InvoiceSummaryReport? _lastReport;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  void _log(String message) {
    print(message); // Also print to console for easier debugging
    setState(() {
      _logOutput = "$message\n\n$_logOutput";
      if (_logOutput.length > 2000) { // Keep log from getting too long
          _logOutput = _logOutput.substring(0, 2000) + "...";
      }
    });
  }

  void _initializeData() {
    // Create some clients
    final client1 = Client(id: 'C001', name: 'Alice Wonderland', email: 'alice@example.com');
    final client2 = Client(id: 'C002', name: 'Bob The Builder');
    manager.addClient(client1);
    manager.addClient(client2);
    _log('Initialized Clients: ${manager.getAllClients().map((c) => c.name).join(', ')}');
    
    _selectedClient = client1;

    // Create some invoices
    final invoice1 = Invoice(
      id: 'INV001',
      clientId: client1.id,
      totalAmount: 150.00,
      issueDate: DateTime.now().subtract(const Duration(days: 10)),
      dueDate: DateTime.now().add(const Duration(days: 20)),
    );
    final invoice2 = Invoice(
      id: 'INV002',
      clientId: client2.id,
      totalAmount: 300.00,
      issueDate: DateTime.now().subtract(const Duration(days: 35)),
      dueDate: DateTime.now().subtract(const Duration(days: 5)), // Overdue
    );
    final invoice3 = Invoice(
      id: 'INV003',
      clientId: client1.id,
      totalAmount: 75.50,
      issueDate: DateTime.now().subtract(const Duration(days: 5)),
      dueDate: DateTime.now().add(const Duration(days: 10)),
    );

    manager.addInvoice(invoice1);
    manager.addInvoice(invoice2);
    manager.addInvoice(invoice3);
    _log('Initialized Invoices: ${manager.getAllInvoices().map((inv) => inv.id).join(', ')}');
    
    _selectedInvoice = invoice1; // Select first invoice by default

    _log('--- Initial State ---');
    manager.getAllInvoices().forEach((inv) {
        _log(inv.toString());
    });
     _log('--------------------');
  }
  
  void _selectInvoice(Invoice? invoice) {
    setState(() {
      _selectedInvoice = invoice;
      _lastPayment = null; // Clear previous payment details when invoice changes
      _lastReceipt = null;
    });
  }

  void _selectClient(Client? client) {
    setState(() {
      _selectedClient = client;
    });
  }

  void _logPaymentDemo() {
    if (_selectedInvoice == null) {
      _log('No invoice selected to log payment.');
      return;
    }
    _log('--- Logging Payment Demo ---');
    _lastPayment = manager.paymentLogger.logPayment(
      invoiceId: _selectedInvoice!.id,
      amount: 50.0,
      method: PaymentMethod.creditCard,
      transactionId: 'TXN${DateTime.now().second}',
    );
    if (_lastPayment != null) {
      _log('Payment logged for ${_selectedInvoice!.id}: \$50.00');
      _log('Updated Invoice: ${manager.getInvoiceById(_selectedInvoice!.id)}');
    } else {
      _log('Failed to log payment for ${_selectedInvoice!.id}.');
    }
  }

  void _generateReceiptDemo() {
    if (_selectedInvoice == null || _lastPayment == null) {
      _log('Cannot generate receipt. Log a payment first for the selected invoice.');
      return;
    }
    _log('--- Generating Receipt Demo ---');
    _lastReceipt = manager.receiptGenerator.generateReceipt(
      invoiceId: _selectedInvoice!.id,
      paymentMade: _lastPayment!,
    );
    if (_lastReceipt != null) {
      _log('Receipt generated for payment ${_lastPayment!.id}.');
      _log('Receipt Details:\n${_lastReceipt!.toFormattedString()}');
    } else {
      _log('Failed to generate receipt.');
    }
  }
  
  void _viewPaymentHistoryDemo() {
    if (_selectedInvoice == null) {
      _log('No invoice selected to view history.');
      return;
    }
    _log('--- Payment History for Invoice ${_selectedInvoice!.id} ---');
    final history = manager.paymentHistoryLog.getPaymentHistory(_selectedInvoice!.id);
    if (history.isEmpty) {
      _log('No payments found for this invoice.');
    } else {
      history.forEach((p) => _log(p.toString()));
    }
  }

  void _checkInvoiceStatusDemo() {
    if (_selectedInvoice == null) {
      _log('No invoice selected to check status.');
      return;
    }
    _log('--- Checking Invoice Status for ${_selectedInvoice!.id} ---');
    // Recalculate status to ensure it's up-to-date (especially for overdue)
    manager.invoiceStatusTracker.recalculateInvoiceStatus(_selectedInvoice!.id);
    final status = manager.invoiceStatusTracker.getInvoiceStatus(_selectedInvoice!.id);
    if (status != null) {
      _log('Invoice ${_selectedInvoice!.id} status: ${invoiceStatusToString(status)}');
      _log('Full Invoice Details: ${manager.getInvoiceById(_selectedInvoice!.id)}');
    } else {
      _log('Could not get status for invoice ${_selectedInvoice!.id}');
    }
  }
  
  void _generateReportAllDemo() {
    _log('--- Generating Report (All Invoices) ---');
    _lastReport = manager.invoiceSummaryReport.generateReport();
    _log('Report Generated:\n${_lastReport!.toFormattedString()}');
  }

  void _generateReportFilteredDemo() {
     if (_selectedClient == null) {
      _log('No client selected for filtered report.');
      return;
    }
    _log('--- Generating Report (Filtered: Client ${_selectedClient!.id}, Status: Unpaid) ---');
    _lastReport = manager.invoiceSummaryReport.generateReport(
      clientIdFilter: _selectedClient!.id,
      statusFilter: InvoiceStatus.unpaid,
      // startDate: DateTime.now().subtract(Duration(days: 30))
    );
     _log('Report Generated:\n${_lastReport!.toFormattedString()}');
  }


  @override
  Widget build(BuildContext context) {
    final allInvoices = manager.getAllInvoices();
    final allClients = manager.getAllClients();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment System Demo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 1,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('Select Invoice:', style: Theme.of(context).textTheme.titleMedium),
                    if (allInvoices.isEmpty) const Text('No invoices available.'),
                    ...allInvoices.map((inv) => RadioListTile<Invoice>(
                          title: Text('${inv.id} (Client: ${inv.clientId}, Amt: \$${inv.totalAmount.toStringAsFixed(2)}, Status: ${invoiceStatusToString(inv.status)})'),
                          value: inv,
                          groupValue: _selectedInvoice,
                          onChanged: _selectInvoice,
                        )),
                    const SizedBox(height: 10),
                    Text('Select Client (for filtering reports):', style: Theme.of(context).textTheme.titleMedium),
                     if (allClients.isEmpty) const Text('No clients available.'),
                    ...allClients.map((client) => RadioListTile<Client>(
                          title: Text('${client.name} (ID: ${client.id})'),
                          value: client,
                          groupValue: _selectedClient,
                          onChanged: _selectClient,
                        )),

                    const SizedBox(height: 20),
                    ElevatedButton(onPressed: _logPaymentDemo, child: const Text('1. Log \$50 Payment (to selected)')),
                    const SizedBox(height: 10),
                    ElevatedButton(onPressed: _generateReceiptDemo, child: const Text('2. Generate Receipt (for last payment)')),
                    const SizedBox(height: 10),
                    ElevatedButton(onPressed: _viewPaymentHistoryDemo, child: const Text('3. View Payment History (of selected)')),
                    const SizedBox(height: 10),
                    ElevatedButton(onPressed: _checkInvoiceStatusDemo, child: const Text('4. Check/Update Invoice Status (of selected)')),
                    const SizedBox(height: 10),
                    ElevatedButton(onPressed: _generateReportAllDemo, child: const Text('5. Generate Report (All Invoices)')),
                    const SizedBox(height: 10),
                    ElevatedButton(onPressed: _generateReportFilteredDemo, child: const Text('6. Generate Report (Filtered)')),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Log Output:', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(8.0),
                      color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
                      child: SingleChildScrollView(
                        reverse: true, // Scroll to bottom
                        child: Text(_logOutput, style: Theme.of(context).textTheme.bodySmall),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}